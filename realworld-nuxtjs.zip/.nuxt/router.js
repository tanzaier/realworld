import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from '@nuxt/ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _4b106202 = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _342ab9f4 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _5164ccf4 = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _648c3074 = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _838c2290 = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _62ae157c = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _4b5673c1 = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _4b106202,
    children: [{
      path: "",
      component: _342ab9f4,
      name: "home"
    }, {
      path: "/login",
      component: _5164ccf4,
      name: "login"
    }, {
      path: "/register",
      component: _5164ccf4,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _648c3074,
      name: "profile"
    }, {
      path: "/settings",
      component: _838c2290,
      name: "settings"
    }, {
      path: "/editor",
      component: _62ae157c,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _4b5673c1,
      name: "article"
    }]
  }],

  fallback: false
}

function decodeObj(obj) {
  for (const key in obj) {
    if (typeof obj[key] === 'string') {
      obj[key] = decode(obj[key])
    }
  }
}

export function createRouter () {
  const router = new Router(routerOptions)

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    const r = resolve(to, current, append)
    if (r && r.resolved && r.resolved.query) {
      decodeObj(r.resolved.query)
    }
    return r
  }

  return router
}
